#include <stdint.h>
#include <stdbool.h>
#include "reg_eta_ecm3532_m3.h"
#include "reg.h"

